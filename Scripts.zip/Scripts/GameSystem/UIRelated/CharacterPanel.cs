﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterPanel : MonoBehaviour
{
    private static CharacterPanel instance;

    [SerializeField]
    private CanvasGroup canvasGroup;

    [SerializeField]
    private CharButton Head, Shoulders, Chest, Cloak, Legs, Belt, Hands, Bracers, Ring, Ring2, Neck, Feets, MainHand, Throwables, OffHand;

    public CharButton MySelectedButton { get; set; }
    public static CharacterPanel MyInstance 
    {
        get
        {
            if(instance== null)
            {
                instance = GameObject.FindObjectOfType<CharacterPanel>();
            }

            return instance;
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OpenClose()
    {
        if (canvasGroup.alpha <= 0)
        {
            canvasGroup.blocksRaycasts = true;
            canvasGroup.alpha = 1;
        }
        else
        {
            canvasGroup.blocksRaycasts = false;
            canvasGroup.alpha = 0;
        }
    }

    public void EquipArmor(Armor armor)
    {
        switch (armor.MyArmorType)
        {
            case ArmorType.Head:
                Head.EquipArmor(armor);
                break;
            case ArmorType.Shoulders:
                Shoulders.EquipArmor(armor);
                break;
            case ArmorType.Chest:
                Chest.EquipArmor(armor);
                break;
            case ArmorType.Cloak:
                Cloak.EquipArmor(armor);
                break;
            case ArmorType.Legs:
                Legs.EquipArmor(armor);
                break;
            case ArmorType.Belt:
                Belt.EquipArmor(armor);
                break;
            case ArmorType.Hands:
                Hands.EquipArmor(armor);
                break;
            case ArmorType.Bracers:
                Bracers.EquipArmor(armor);
                break;
            case ArmorType.Ring:
                if(Ring.MyEquipedArmor == null)
                Ring.EquipArmor(armor);
                else
                Ring2.EquipArmor(armor);
                break;
            case ArmorType.Neck:
                Neck.EquipArmor(armor);
                break;
            case ArmorType.Feets:
                Feets.EquipArmor(armor);
                break;
            case ArmorType.MainHand:
                MainHand.EquipArmor(armor);
                break;
            case ArmorType.Throwables:
                Throwables.EquipArmor(armor);
                break;
            case ArmorType.OffHand:
                OffHand.EquipArmor(armor);
                break;
            default:
                break;
        }
    }
}
