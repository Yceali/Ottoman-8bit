﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class HandScript : MonoBehaviour
{
    private static HandScript instance;

    public static HandScript m_instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<HandScript>();
            }

            return instance;
        }
    }

    public IMovable MyMovable { get; set; }

    private Image icon;

    [SerializeField]
    private Vector3 offset;
    // Start is called before the first frame update
    void Start()
    {
        icon = GetComponent<Image>();
    }

    // Update is called once per frame
    void Update()
    {
        icon.transform.position = Input.mousePosition+offset;

        if (Input.GetMouseButton(0) && !EventSystem.current.IsPointerOverGameObject() && m_instance.MyMovable != null)
        {
            DeleteItem();
        }
    }

    public void TakeMovable(IMovable movable)
    {
        this.MyMovable = movable;
        icon.sprite = movable.MyIcon;
        icon.enabled = true;
    }

    public IMovable Put()
    {
        IMovable tmp = MyMovable;
        MyMovable = null;
        icon.enabled = false;

        return tmp;
    }

    public void Drop()
    {
        MyMovable = null;
        icon.enabled = false;
        InventoryScript.m_instance.MyfromSlot = null;
    }

    public void DeleteItem()
    {
        

        if (MyMovable is Item )
        {
            Item item = (Item)MyMovable;
            if (item.MySlot != null)
            {
                item.MySlot.Clear();
            }
            else if (item.MyCharButton != null)
            {
                item.MyCharButton.DequipArmor();
            }
        }

        Drop();

        InventoryScript.m_instance.MyfromSlot = null;
    }
}
