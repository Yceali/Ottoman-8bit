﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class TeleportLocations : MonoBehaviour
{
    [SerializeField]
    private Transform[] teleportLocs;
    [SerializeField]
    private Tilemap[] tileMaps;
    [SerializeField]
    private CameraFollow mainCamera;
    [SerializeField]
    private AStar aStar;

    public Transform[] MyTeleportLocs { get => teleportLocs; set => teleportLocs = value; }
    public Tilemap[] MyTileMaps { get => tileMaps; set => tileMaps = value; }
    public CameraFollow MyMainCamera { get => mainCamera; set => mainCamera = value; }
    public AStar MyAStar { get => aStar; set => aStar = value; }
}
