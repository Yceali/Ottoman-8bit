﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Tilemaps;

public class CollectiblePlant : Tile
{

#if UNITY_EDITOR
    [MenuItem("Assets/Create/Tiles/CollectiblePlant")]
    public static void CreateWaterTile()
    {
        string path = EditorUtility.SaveFilePanelInProject("Save CollectiblePlant", "CollectiblePlant", "asset", "Save CollectiblePlant", "Assets");
        if (path == "")
        {
            return;
        }
        AssetDatabase.CreateAsset(ScriptableObject.CreateInstance<CollectiblePlant>(), path);
    }

#endif
}
